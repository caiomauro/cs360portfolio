package com.example.pagepal;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import android.content.Intent;
import android.util.Log;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private EditText usernameField, emailField, passwordField;
    private Button registerBtn, loginBtn;
    private DBHandler dbHandler;
    private long lastClickTime = 0;
    private static final long CLICK_TIME_INTERVAL = 1000; // Interval between button clicks in milliseconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameField = findViewById(R.id.idEdtUsername);
        emailField = findViewById(R.id.idEdtEmail);
        passwordField = findViewById(R.id.idEdtPassword);

        registerBtn = findViewById(R.id.idBtnRegister);
        loginBtn = findViewById(R.id.idBtnLogin);

        dbHandler = new DBHandler(MainActivity.this);

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check for rapid button clicks
                if (System.currentTimeMillis() - lastClickTime < CLICK_TIME_INTERVAL) {
                    Log.d(TAG, "Multiple clicks detected, ignoring.");
                    return;
                }
                lastClickTime = System.currentTimeMillis();

                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check for rapid button clicks
                if (System.currentTimeMillis() - lastClickTime < CLICK_TIME_INTERVAL) {
                    Log.d(TAG, "Multiple clicks detected, ignoring.");
                    return;
                }
                lastClickTime = System.currentTimeMillis();

                // Get data from EditText fields
                String username = usernameField.getText().toString();
                String email = emailField.getText().toString();
                String password = passwordField.getText().toString();

                // Validate input fields
                if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter all the data.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Register user in the database
                dbHandler.register_user(username, email, password);

                // Display success message
                Toast.makeText(MainActivity.this, "User registered", Toast.LENGTH_SHORT).show();

                // Clear input fields
                usernameField.setText("");
                emailField.setText("");
                passwordField.setText("");
            }
        });
    }
}
