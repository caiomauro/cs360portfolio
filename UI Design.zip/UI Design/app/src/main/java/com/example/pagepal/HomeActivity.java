package com.example.pagepal;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity {

    private DBHandler dbHandler;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        dbHandler = new DBHandler(this);

        // Find views
        TextView textView = findViewById(R.id.textView);
        EditText pagesReadEditText = findViewById(R.id.pagesReadEditText);
        Button addButton = findViewById(R.id.addButton);
        GridView gridView = findViewById(R.id.gridView);

        // Retrieve the user ID from the UserSession class
        userId = UserSession.getInstance().getUserId();

        // Display the user ID if it's available, otherwise show a message
        if (userId != -1) {
            textView.setText("Hello, User " + userId + "!");
        } else {
            Toast.makeText(this, "User ID not available", Toast.LENGTH_SHORT).show();
        }

        // Set OnClickListener for the Add button
        addButton.setOnClickListener(view -> {
            // Get the pages read from the EditText
            String pagesReadString = pagesReadEditText.getText().toString();
            if (!pagesReadString.isEmpty()) {
                int pagesRead = Integer.parseInt(pagesReadString);
                long currentTime = System.currentTimeMillis();
                // Call a method to add the pages read
                dbHandler.add_daily_reading(userId, pagesRead, currentTime);
                // Refresh the grid
                displayGrid();
                // Clear the EditText
                pagesReadEditText.setText("");
            } else {
                Toast.makeText(this, "Please enter pages read", Toast.LENGTH_SHORT).show();
            }
        });

        // Display the grid
        displayGrid();
    }

    private void displayGrid() {
        // Get the last 7 days' readings
        List<String[]> readings = dbHandler.get_daily_readings(userId, 7);
        GridView gridView = findViewById(R.id.gridView);

        // Create a list to hold the formatted readings
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);

        // Format the readings and add them to the list
        for (String[] reading : readings) {
            long unixTimestamp = Long.parseLong(reading[0]);
            int pagesRead = Integer.parseInt(reading[1]);
            String formattedDate = formatDate(unixTimestamp);
            String formattedReading = formattedDate + ": " + pagesRead + " pages read";
            adapter.add(formattedReading);
        }

        // Set the adapter to the GridView
        gridView.setAdapter(adapter);
    }

    private String formatDate(long unixTimestamp) {
        // Convert Unix timestamp to date
        Date date = new Date(unixTimestamp);
        // Format the date
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return sdf.format(date);
    }
}
