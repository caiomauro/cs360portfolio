package com.example.pagepal;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;

import java.io.File;
import java.lang.reflect.Array;

public class DBHandler extends SQLiteOpenHelper {
    //Database name
    private static final String DB_NAME = "bookwormDB.db";
    //Database version
    private static final int DB_VERSION = 1;
    //-----------------------------------------------------------------
    //Users authentication table name
    private static final String USERS_TABLE = "users";
    //ID column for users, goal, daily table
    private static final String USER_ID = "id";
    //Username column for users table
    private static final String USER_USERNAME = "username";
    //Email column for users table
    private static final String USER_EMAIL = "email";
    //password column for users table
    private static final String USER_PASSWORD = "password";
    //-----------------------------------------------------------------
    //Users goal data table name
    private static final String GOAL_TABLE = "goal";
    //Target column for goal table
    private static final String GOAL_TARGET = "target";
    //Day added column for daily
    private static final String GOAL_DATE = "date";
    //-----------------------------------------------------------------
    //Users daily read data table name
    private static final String DAILY_TABLE = "daily";
    //Amount column for daily
    private static final String DAILY_AMOUNT = "amount";
    //Day added column for daily
    private static final String DAILY_DATE = "date";

    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String user_table_query = "CREATE TABLE " + USERS_TABLE + " ("
                + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_USERNAME + " TEXT,"
                + USER_EMAIL + " TEXT,"
                + USER_PASSWORD + " TEXT)";

        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(user_table_query);

        String goal_table_query = "CREATE TABLE " + GOAL_TABLE + " ("
                + USER_ID + " INTEGER, "
                + GOAL_TARGET + " INTEGER,"
                + GOAL_DATE + " INTEGER)";

        db.execSQL(goal_table_query);

        String daily_table_query = "CREATE TABLE " + DAILY_TABLE + " ("
                + USER_ID + " INTEGER, "
                + DAILY_AMOUNT + " INTEGER,"
                + DAILY_DATE + " INTEGER)";

        db.execSQL(daily_table_query);
    }

    public void register_user(String username, String email, String password ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(USER_USERNAME, username);
        values.put(USER_EMAIL, email);
        values.put(USER_PASSWORD, password);

        db.insert(USERS_TABLE, null, values);

        db.close();
    }

    public boolean login_user(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Define the columns you want to retrieve from the database
        String[] columns = { USER_ID };

        // Define the selection criteria (WHERE clause)
        String selection = USER_USERNAME + " = ? AND " + USER_PASSWORD + " = ?";

        // Define the selection arguments
        String[] selectionArgs = { username, password };

        // Execute the query
        Cursor cursor = db.query(USERS_TABLE, columns, selection, selectionArgs, null, null, null);

        // Check if the cursor contains any rows
        boolean loginSuccessful = cursor.getCount() > 0;

        // Close the cursor and database connection
        cursor.close();
        db.close();

        // Return true if the login was successful, otherwise false
        return loginSuccessful;
    }

    @SuppressLint("Range")
    public int get_user_id(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { USER_ID };
        String selection = USER_USERNAME + " = ? AND " + USER_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };

        // Execute the query
        Cursor cursor = db.query(USERS_TABLE, columns, selection, selectionArgs, null, null, null);

        int userId = -1; // Default value indicating user not found

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndex(USER_ID));
            // Set the user ID in the UserSession class
            UserSession.getInstance().setUserId(userId);
        }

        cursor.close();
        db.close();

        return userId;
    }

    public void add_daily_reading(int id, int pagesRead, long unixDate) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USER_ID, id);
        values.put(DAILY_AMOUNT, pagesRead);
        values.put(DAILY_DATE, unixDate);

        db.insert(DAILY_TABLE, null, values);
        db.close();
    }

    public void delete_daily_reading(int userId, long unixDate) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Define the WHERE clause
        String selection = USER_ID + " = ? AND " + DAILY_DATE + " = ?";
        // Define the selection arguments
        String[] selectionArgs = { String.valueOf(userId), String.valueOf(unixDate) };

        // Delete the entry
        db.delete(DAILY_TABLE, selection, selectionArgs);

        db.close();
    }

    public void update_daily_reading(int userId, long unixDate, int newPagesRead) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Create ContentValues object to hold the new values
        ContentValues values = new ContentValues();
        values.put(DAILY_AMOUNT, newPagesRead);

        // Define the WHERE clause
        String selection = USER_ID + " = ? AND " + DAILY_DATE + " = ?";
        // Define the selection arguments
        String[] selectionArgs = { String.valueOf(userId), String.valueOf(unixDate) };

        // Update the entry
        db.update(DAILY_TABLE, values, selection, selectionArgs);

        db.close();
    }


    public List<String[]> get_daily_readings(int id, int limit) {
        List<String[]> readings = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { DAILY_DATE, DAILY_AMOUNT };
        String selection = USER_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        // Adjust the query to order by date in descending order and limit the result
        String orderBy = DAILY_DATE + " DESC";
        String limitClause = String.valueOf(limit);

        Cursor cursor = db.query(DAILY_TABLE, columns, selection, selectionArgs, null, null, orderBy, limitClause);

        // Iterate over the cursor and populate the list of arrays
        if (cursor.moveToFirst()) {
            do {
                int dateIndex = cursor.getColumnIndex(DAILY_DATE);
                int amountIndex = cursor.getColumnIndex(DAILY_AMOUNT);

                // Get the date and pages read
                long unixTimestamp = cursor.getLong(dateIndex);
                int pagesRead = cursor.getInt(amountIndex);

                // Create an array containing the date and pages read
                String[] reading = {String.valueOf(unixTimestamp), String.valueOf(pagesRead)};

                // Add the array to the list
                readings.add(reading);
            } while (cursor.moveToNext());
        }

        // Close cursor and database connection
        cursor.close();
        db.close();

        return readings;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USERS_TABLE);
        onCreate(db);
    }
}
